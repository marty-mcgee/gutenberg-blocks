/**
 * Import blocks
 */
import './testimonial-slider/block.js';
//import './button/block.js';
import './query-builder/block.js';
import './query-builder-julian/block.js';

/* from WCN Block One */
//import './load-post/block.js';
//import './editable-block/block.js';
import './random-image/block.js';
